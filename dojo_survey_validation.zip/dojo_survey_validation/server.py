from flask import Flask, render_template, request, redirect, flash
app = Flask(__name__)
app.secret_key = 'supersecret'

@app.route('/')
def index():
	return render_template('index.html')

@app.route('/result', methods=["POST"])
def create_user():
	print "Got post info"
	name = request.form['name']
	location = request.form['location']
	language = request.form['language']
	comment = request.form['comment']
	
	#dax wrote this 
	has_name = False
	has_comment = False
	has_under_120 = False

	if name == "":
		flash("Name is empty.")
	else:
		has_name = True

	if comment == "":
		flash("Comment is empty")
	else:
		has_comment = True

	if (len(comment) > 120):
		flash("Comment is longer than 120 characters.")
	else:
		has_under_120 = True
	
	if (has_name == True) and (has_comment == True) and (has_under_120 ==True):
		return render_template('result.html', name=name, location=location, language=language, comment=comment)
	else:
		return redirect('/')

app.run(debug=True)