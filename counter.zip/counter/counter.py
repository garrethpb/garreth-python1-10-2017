from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'secret'

#code for basic counter:
@app.route('/')
def counter():
	try:
		session['counter'] += 1
	except:
		session['counter'] = 1
	return render_template('index.html')

# add button that increments by 2
# @app.route('/add2', methods=['POST'])
# def increment():
# 	print 'Hello again!'
# 	session['counter'] += 1
# 	return redirect('/')

# add button that resets counter (I could not get this to work)
# @app.route('/resent_count', methods=['POST'])
# def reset():
# 	session['counter'] = 0
# 	return redirect('/')

app.run(debug=True)