from flask import Flask, render_template, request, redirect, session
import random
app = Flask(__name__)
app.secret_key = 'secret'

@app.route('/')
def index():
	if 'gold' not in session:
		session['gold'] = 0
		session['activities'] = []
	return render_template('index.html', gold=session['gold'], activities=session['activities'])

@app.route('/process_money', methods=["POST"])
def process_money():
	building = request.form['building']
	if building == 'farm':
		gold = random.randrange(10,21)
		session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	elif building == 'cave':
		gold = random.randrange(5,11)
		session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	elif building == 'house':
		gold = random.randrange(2,6)
		session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	elif building == 'casino':
		gold = random.randrange(-50,51)
		session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	session['gold'] += gold
	return redirect('/')


app.run(debug=True)



# ninja gold